#pragma once

#include <stdint.h>

/**
 * Reverse the bits of a given byte
 */
uint8_t reverseBits(uint8_t byte);